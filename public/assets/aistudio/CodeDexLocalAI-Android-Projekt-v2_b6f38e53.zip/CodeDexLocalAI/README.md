# CodeDex Local AI — Android-Studio-Projekt

Starter-Projekt für eine kostenlose Android-App mit lokalem Coding-Chat, Code-Editor, GitHub-/ZIP-Import und Dateiverwaltung.

## Aktueller Stand
- Enthält Android-Quellcode und Gradle-Konfiguration.
- **Keine APK wurde kompiliert** und kein KI-Modell ist enthalten.
- Die lokale Inferenz ist für MediaPipe LLM Inference vorbereitet. Importiere eine kompatible `.task`-Modelldatei in der App. Nicht jedes Modell (insbesondere nicht jedes GGUF-Modell) ist mit MediaPipe kompatibel.
- Bei 6 GB RAM mit einem kleinen, quantisierten und ausdrücklich kompatiblen Modell starten. Die tatsächliche Leistung hängt von Gerät, freiem RAM, CPU/GPU und Modell ab.
- Internet wird für Modell-/Projekt-Downloads benötigt; nach dem Modellimport kann die Inferenz offline erfolgen.

## APK bauen
1. ZIP entpacken.
2. In Android Studio **Open** wählen und den Ordner `CodeDexLocalAI` öffnen.
3. JDK 17 verwenden und Gradle-Sync durchführen.
4. Auf dem Android-Gerät testen.
5. **Build → Build Bundle(s) / APK(s) → Build APK(s)** wählen.
6. Die Debug-APK liegt bei erfolgreichem Build normalerweise unter `app/build/outputs/apk/debug/app-debug.apk`.

## Enthaltene Funktionen
- Chat-Oberfläche und lokale Modellinferenz
- Import einer lokalen Modelldatei über Android-Dateiauswahl
- einfacher Code-Editor mit Speichern
- öffentliche GitHub-Repository-ZIP-Downloads
- direkte ZIP-URL herunterladen und entpacken
- Projektdateien auflisten, Textdateien öffnen und Dateien löschen

## Sicherheits- und Funktionshinweise
- GitHub-Import ist für öffentliche Repositories ausgelegt; private Repositories benötigen Authentifizierung, die nicht eingebaut ist.
- Heruntergeladene Dateien werden nicht automatisch ausgeführt. Fremden Code prüfen, bevor du ihn nutzt.
- Der Prototyp ist nicht als veröffentlichungsfertige App geprüft. Vor Veröffentlichung Fehlerbehandlung, Download-Limits, Lizenzprüfung und Tests ergänzen.
