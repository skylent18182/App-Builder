package dev.codedex.localai

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CodeDexApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CodeDexApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var prompt by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("Importiere ein kompatibles lokales .task-Modell, um den Chat zu starten.") }
    var busy by remember { mutableStateOf(false) }
    var modelPath by remember { mutableStateOf(File(context.filesDir, "local_model.task").takeIf { it.exists() }?.absolutePath ?: "") }
    var downloadUrl by remember { mutableStateOf("") }
    var projectStatus by remember { mutableStateOf("Noch keine Projekte importiert.") }
    var editorText by remember { mutableStateOf("// CodeDex Editor\n// Schreibe Code und speichere ihn als Datei.") }
    var editorName by remember { mutableStateOf("untitled.txt") }
    var files by remember { mutableStateOf(listProjectFiles(context)) }
    var appPrompt by remember { mutableStateOf("") }
    var appBuildStatus by remember { mutableStateOf("Beschreibe deine Android-App. CodeDex erstellt ein Android-Studio-Projekt zum Exportieren.") }
    var generatedAppDir by remember { mutableStateOf<File?>(null) }
    var engine by remember { mutableStateOf<LlmInference?>(null) }

    val projectZipExporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri: Uri? ->
        val folder = generatedAppDir
        if (uri != null && folder != null) {
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { out ->
                            ZipOutputStream(out).use { zip ->
                                folder.walkTopDown().filter { it.isFile }.forEach { file ->
                                    val relative = file.relativeTo(folder).invariantSeparatorsPath
                                    zip.putNextEntry(java.util.zip.ZipEntry("${folder.name}/$relative"))
                                    file.inputStream().use { it.copyTo(zip) }
                                    zip.closeEntry()
                                }
                            }
                        } ?: error("Zieldatei konnte nicht geöffnet werden")
                    }
                    appBuildStatus = "Android-Projekt-ZIP wurde exportiert. Öffne es in einer Android-Build-Umgebung, um eine APK zu kompilieren."
                } catch (e: Exception) { appBuildStatus = "Export fehlgeschlagen: ${e.message}" }
            }
        }
    }

    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            busy = true
            try {
                val target = File(context.filesDir, "local_model.task")
                withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri).use { input ->
                        requireNotNull(input) { "Datei konnte nicht gelesen werden" }.use { source ->
                            target.outputStream().use { destination -> source.copyTo(destination) }
                        }
                    }
                }
                modelPath = target.absolutePath
                engine?.close(); engine = null
                answer = "Modell importiert. Tippe auf „Modell laden“."
            } catch (e: Exception) { answer = "Modellimport fehlgeschlagen: ${e.message}" }
            finally { busy = false }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(topBar = { TopAppBar(title = { Text("CodeDex • Local AI") }) }, bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Text("✦") }, label = { Text("Chat") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Text("{ }") }, label = { Text("Code") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Text("↓") }, label = { Text("Import") })
                NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Text("▤") }, label = { Text("Dateien") })
                NavigationBarItem(selected = tab == 4, onClick = { tab = 4 }, icon = { Text("APK") }, label = { Text("App bauen") })
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                when (tab) {
                    0 -> {
                        Text("Lokaler Coding-Assistent", style = MaterialTheme.typography.titleLarge)
                        Text(if (engine == null) "KI-Status: nicht geladen" else "KI-Status: lokal geladen")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { modelPicker.launch(arrayOf("*/*")) }) { Text("Modell importieren") }
                            OutlinedButton(enabled = modelPath.isNotBlank() && File(modelPath).exists() && !busy, onClick = {
                                scope.launch {
                                    busy = true
                                    try {
                                        engine?.close()
                                        engine = withContext(Dispatchers.IO) {
                                            val options = LlmInference.LlmInferenceOptions.builder().setModelPath(modelPath).setMaxTokens(512).build()
                                            LlmInference.createFromOptions(context, options)
                                        }
                                        answer = "Lokales Modell geladen. Du kannst offline fragen."
                                    } catch (e: Exception) {
                                        answer = "Modell konnte nicht geladen werden: ${e.message}\nPrüfe, ob es ein kompatibles MediaPipe-.task-Modell ist."
                                    } finally { busy = false }
                                }
                            }) { Text("Modell laden") }
                        }
                        Card(Modifier.weight(1f).fillMaxWidth()) {
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) { Text(answer) }
                        }
                        OutlinedTextField(value = prompt, onValueChange = { prompt = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Frage zu Code…") }, minLines = 2)
                        Button(modifier = Modifier.fillMaxWidth(), enabled = !busy && prompt.isNotBlank() && engine != null, onClick = {
                            val question = prompt.trim()
                            scope.launch {
                                busy = true
                                try {
                                    answer = withContext(Dispatchers.IO) {
                                        engine?.generateResponse("Du bist CodeDex, ein hilfreicher Coding-Assistent. Antworte auf Deutsch. Erkläre Annahmen und liefere sicheren, verständlichen Code.\n\n$question") ?: "Keine lokale KI geladen."
                                    }
                                } catch (e: Exception) { answer = "KI-Fehler: ${e.message}" }
                                finally { busy = false }
                            }
                        }) { Text(if (busy) "Bitte warten…" else "Lokal fragen") }
                        Text("Die KI rechnet lokal. Downloads benötigen Internet.", style = MaterialTheme.typography.bodySmall)
                    }
                    1 -> {
                        Text("Code-Editor", style = MaterialTheme.typography.titleLarge)
                        OutlinedTextField(value = editorName, onValueChange = { editorName = it }, label = { Text("Dateiname") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(value = editorText, onValueChange = { editorText = it }, modifier = Modifier.weight(1f).fillMaxWidth(), label = { Text("Quellcode / Text") }, minLines = 12)
                        Button(onClick = {
                            scope.launch {
                                try {
                                    val safeName = editorName.substringAfterLast('/').substringAfterLast('\\').ifBlank { "untitled.txt" }
                                    withContext(Dispatchers.IO) { File(context.filesDir, "projects/$safeName").apply { parentFile?.mkdirs(); writeText(editorText) } }
                                    files = listProjectFiles(context)
                                    Toast.makeText(context, "Datei gespeichert", Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) { Toast.makeText(context, e.message ?: "Fehler", Toast.LENGTH_LONG).show() }
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Datei speichern") }
                    }
                    2 -> {
                        Text("GitHub- & ZIP-Import", style = MaterialTheme.typography.titleLarge)
                        Text("Öffentliche GitHub-Repositories oder direkte ZIP-Links importieren.")
                        OutlinedTextField(value = downloadUrl, onValueChange = { downloadUrl = it }, modifier = Modifier.fillMaxWidth(), label = { Text("GitHub-URL oder ZIP-URL") })
                        Button(enabled = !busy && downloadUrl.isNotBlank(), onClick = {
                            scope.launch {
                                busy = true; projectStatus = "Download läuft…"
                                try {
                                    val url = normalizeZipUrl(downloadUrl.trim())
                                    val folder = withContext(Dispatchers.IO) { downloadAndExtract(context, url) }
                                    projectStatus = "Import abgeschlossen: ${folder.name}"
                                    files = listProjectFiles(context); downloadUrl = ""
                                } catch (e: Exception) { projectStatus = "Import fehlgeschlagen: ${e.message}" }
                                finally { busy = false }
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Lädt…" else "Herunterladen & entpacken") }
                        Card { Text(projectStatus, Modifier.padding(12.dp)) }
                        Text("Fremden Code vor der Nutzung prüfen. Die App führt Dateien nicht automatisch aus.", style = MaterialTheme.typography.bodySmall)
                    }
                    4 -> {
                        Text("Android-App erstellen", style = MaterialTheme.typography.titleLarge)
                        Text("Beschreibe deine App. Die lokale Coding-KI erstellt eine MainActivity und ein Android-Studio-Projekt, das du als ZIP exportieren kannst.", style = MaterialTheme.typography.bodyMedium)
                        OutlinedTextField(
                            value = appPrompt,
                            onValueChange = { appPrompt = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Was soll deine Android-App können?") },
                            placeholder = { Text("Erstelle eine To-do-App mit dunklem Neon-Design, Kategorien und lokalem Speicher…") },
                            minLines = 4
                        )
                        Button(
                            enabled = !busy && appPrompt.isNotBlank() && engine != null,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                val specification = appPrompt.trim()
                                scope.launch {
                                    busy = true
                                    appBuildStatus = "Die lokale KI erstellt den App-Quellcode…"
                                    try {
                                        val generated = withContext(Dispatchers.IO) {
                                            engine?.generateResponse(
                                                "Du bist CodeDex, ein erfahrener Android-Entwickler. Erzeuge eine vollständige einzelne Kotlin-Datei MainActivity.kt für ein Android-Projekt mit Jetpack Compose und Material 3. App-Anforderung: $specification. Nutze nur Android- und Compose-APIs. Gib ausschließlich Kotlin-Quellcode zurück, keine Markdown-Codezäune und keine Erklärung. Verwende package dev.codedex.generated. Keine Netzwerk-API und keine erfundenen Bibliotheken."
                                            ) ?: error("Bitte zuerst ein lokales KI-Modell laden.")
                                        }
                                        val project = withContext(Dispatchers.IO) { createGeneratedAndroidProject(context, specification, generated) }
                                        generatedAppDir = project
                                        appBuildStatus = "Quellprojekt erstellt: ${project.name}. Prüfe den Code, bevor du ihn kompilierst. Du kannst das Projekt jetzt als ZIP exportieren."
                                        files = listProjectFiles(context)
                                    } catch (e: Exception) {
                                        appBuildStatus = "App-Erstellung fehlgeschlagen: ${e.message}"
                                    } finally { busy = false }
                                }
                            }
                        ) { Text(if (busy) "Erstelle Projekt…" else "Android-Projekt generieren") }
                        Button(
                            enabled = generatedAppDir != null && !busy,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { projectZipExporter.launch("CodeDex-Android-App.zip") }
                        ) { Text("Projekt-ZIP exportieren") }
                        Card(Modifier.weight(1f).fillMaxWidth()) {
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
                                Text(appBuildStatus)
                            }
                        }
                        Text("Wichtig: Die App erzeugt Quellcode und ein Android-Studio-Projekt, keine sofort kompilierte APK. Für die APK muss das Projekt mit Android SDK/Gradle gebaut werden. KI-generierter Code kann Fehler enthalten.", style = MaterialTheme.typography.bodySmall)
                    }
                    else -> {
                        Text("Projektdateien", style = MaterialTheme.typography.titleLarge)
                        Button(onClick = { files = listProjectFiles(context) }) { Text("Aktualisieren") }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(files, key = { it.absolutePath }) { file ->
                                Card { Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                    Text(file.name, style = MaterialTheme.typography.titleMedium); Text("${file.length()} Bytes")
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        TextButton(onClick = {
                                            if (file.isFile && file.length() < 1_000_000) {
                                                editorName = file.name
                                                editorText = runCatching { file.readText() }.getOrElse { "Kann Datei nicht als Text öffnen: ${it.message}" }
                                                tab = 1
                                            } else Toast.makeText(context, "Nur kleine Textdateien können geöffnet werden.", Toast.LENGTH_SHORT).show()
                                        }) { Text("Öffnen") }
                                        TextButton(onClick = {
                                            val ok = file.deleteRecursively(); files = listProjectFiles(context)
                                            Toast.makeText(context, if (ok) "Gelöscht" else "Löschen fehlgeschlagen", Toast.LENGTH_SHORT).show()
                                        }) { Text("Löschen") }
                                    }
                                } }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun normalizeZipUrl(input: String): String {
    require(input.startsWith("https://") || input.startsWith("http://")) { "Bitte eine HTTP(S)-URL eingeben." }
    val uri = Uri.parse(input)
    val host = uri.host?.lowercase() ?: throw IllegalArgumentException("Ungültige URL")
    if (host == "github.com" || host == "www.github.com") {
        val parts = uri.pathSegments
        require(parts.size >= 2) { "GitHub-URL muss OWNER/REPO enthalten." }
        val owner = parts[0]; val repo = parts[1].removeSuffix(".git")
        return "https://api.github.com/repos/$owner/$repo/zipball"
    }
    require(host.endsWith("githubusercontent.com") || uri.path?.lowercase()?.endsWith(".zip") == true) {
        "Nutze eine GitHub-Repository-URL oder direkte .zip-URL."
    }
    return input
}

private fun downloadAndExtract(context: Context, urlString: String): File {
    val root = File(context.filesDir, "projects").apply { mkdirs() }
    val temp = File(context.cacheDir, "project.zip")
    val connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
        connectTimeout = 15000; readTimeout = 30000; instanceFollowRedirects = true
        setRequestProperty("User-Agent", "CodeDexLocalAI/0.1")
    }
    try {
        connection.inputStream.use { input -> temp.outputStream().use { output -> input.copyTo(output) } }
    } finally { connection.disconnect() }
    val target = File(root, "import_${System.currentTimeMillis()}").apply { mkdirs() }
    ZipInputStream(temp.inputStream().buffered()).use { zip ->
        var entry = zip.nextEntry
        while (entry != null) {
            val out = File(target, entry.name)
            require(out.canonicalPath.startsWith(target.canonicalPath + File.separator)) { "Unsicherer ZIP-Pfad erkannt." }
            if (entry.isDirectory) out.mkdirs() else { out.parentFile?.mkdirs(); out.outputStream().use { zip.copyTo(it) } }
            zip.closeEntry(); entry = zip.nextEntry
        }
    }
    temp.delete(); return target
}

private fun listProjectFiles(context: Context): List<File> {
    val root = File(context.filesDir, "projects")
    if (!root.exists()) return emptyList()
    return root.walkTopDown().filter { it.isFile }.take(500).toList()
}


private fun createGeneratedAndroidProject(context: Context, description: String, generatedCode: String): File {
    val safeTitle = "GeneratedApp_${System.currentTimeMillis()}"
    val root = File(context.filesDir, "projects/$safeTitle").apply { mkdirs() }
    val appDir = File(root, "app/src/main/java/dev/codedex/generated").apply { mkdirs() }
    val mainActivity = generatedCode
        .removePrefix("```kotlin").removePrefix("```
").removeSuffix("```").trim()
    File(appDir, "MainActivity.kt").writeText(mainActivity)
    File(root, "settings.gradle.kts").writeText("""
pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }
rootProject.name = "$safeTitle"
include(":app")
""".trimIndent())
    File(root, "build.gradle.kts").writeText("""
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
}
""".trimIndent())
    File(root, "gradle.properties").writeText("org.gradle.jvmargs=-Xmx2g -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
")
    File(root, "app/build.gradle.kts").apply {
        parentFile?.mkdirs()
        writeText("""
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "dev.codedex.generated"
    compileSdk = 35
    defaultConfig { applicationId = "dev.codedex.generated"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
    buildFeatures { compose = true }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
}
""".trimIndent())
    }
    File(root, "app/src/main/AndroidManifest.xml").apply {
        parentFile?.mkdirs()
        writeText("""
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application android:label="CodeDex Generated App" android:theme="@android:style/Theme.Material.Light.NoActionBar">
        <activity android:name="dev.codedex.generated.MainActivity" android:exported="true">
            <intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter>
        </activity>
    </application>
</manifest>
""".trimIndent())
    }
    File(root, "APP_SPECIFICATION.txt").writeText(description)
    File(root, "BUILD_INSTRUCTIONS.txt").writeText("Open this folder in Android Studio, sync Gradle, inspect/fix generated code, then Build > Build APK(s). This export is source code, not a compiled APK.
")
    return root
}
